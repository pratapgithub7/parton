import './index.css'

const Footer = () => (
  <div className="footer">
    <div className="footer_heading">
      <div className="foo">
        <div className="ji">
          <div className="lu">
            <img
              alt="wave"
              className="logo"
              src="https://assets.ccbp.in/frontend/react-js/wave-logo-img.png"
            />
            <h1 className="ton">Parton</h1>
          </div>
          <p className="pa">
            Our modern sales CRM frees you to <br />
            maximize productivity & grow revenue.
          </p>
          <div className="lu">
            <img
              alt="wave"
              className="logo"
              src="https://assets.ccbp.in/frontend/react-js/wave-logo-img.png"
            />
            <img
              alt="wave"
              className="logo"
              src="https://assets.ccbp.in/frontend/react-js/wave-logo-img.png"
            />
          </div>
        </div>
        <ul className="list">
          Solutions
          <li className="item">Email</li>
          <li className="item">Voice & SMS</li>
          <li className="item">Integrations</li>
          <li className="item">Knowledge Base</li>
          <li className="item">Unified Agent View</li>
          <li className="item">Shopify</li>
        </ul>
      </div>
      <ul className="list">
        Resources
        <li className="item">Blog</li>
        <li className="item">Watch a Demo</li>
        <li className="item">Academy</li>
        <li className="item">Webinars</li>
        <li className="item">what1s New</li>
        <li className="item">Developers</li>
      </ul>
      <ul className="list">
        Security
        <li className="item">System Status</li>
        <li className="item">GDPR</li>
        <li className="item">Google API Services</li>
        <li className="item">Disclosure</li>
      </ul>
      <ul className="list">
        Company
        <li className="item">About</li>
        <li className="item">Careers</li>
        <li className="item">Become a Partner</li>
        <li className="item">Contact Us</li>
      </ul>
    </div>
  </div>
)

export default Footer
