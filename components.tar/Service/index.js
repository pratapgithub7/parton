import {Component} from 'react'

import './index.css'

class Service extends Component {
  render() {
    return (
      <div className="service">
        <div className="service_heading">
          <div className="chat">
            <h1 className="she">Services</h1>
            <p className="pp">
              On the other hand we <br />
              denounce with right us <br />
              indignation dislike beguiled
            </p>
          </div>
          <div className="service_card">
            <h1 className="lap">Laptop & repair</h1>
            <img
              src="https://assets.ccbp.in/frontend/react-js/primary-icon-img.png"
              alt="name"
              className="im"
            />
          </div>
          <div className="service_card">
            <h1 className="lap">Computer & repair</h1>
            <img
              src="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
              alt="name"
              className="im"
            />
          </div>
          <div className="service_card">
            <h1 className="lap">Laptop & Mac repair</h1>
            <img
              src="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
              alt="name"
              className="im"
            />
          </div>
          <div className="service_card">
            <h1 className="lap">Tablet & watch repair</h1>
            <img
              src="https://assets.ccbp.in/frontend/react-js/primary-icon-img.png"
              alt="name"
              className="im"
            />
          </div>
          <div className="service_card">
            <h1 className="lap">SmartPhone & repair</h1>
            <img
              src="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
              alt="name"
              className="im"
            />
          </div>
          <div className="cha">
            <div className="mark">
              <button
                type="button"
                onClick={this.onClickLeftArrow}
                className="arrow-button"
              >
                <img
                  src="https://assets.ccbp.in/frontend/react-js/left-arrow-img.png"
                  alt="left arrow"
                />
              </button>
              <button
                type="button"
                onClick={this.onClickRightArrow}
                className="arrow-button"
              >
                <img
                  src="https://assets.ccbp.in/frontend/react-js/right-arrow-img.png"
                  alt="right arrow"
                />
              </button>
            </div>
            <div className="more">
              <p className="mo">MORE SERVICES</p>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Service
