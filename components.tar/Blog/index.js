import './index.css'

const Blog = () => (
  <div className="blog">
    <div className="blog_heading">
      <div className="card_1">
        <img
          src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/goa-c1-img.png"
          alt="name"
          className="k"
        />
        <h1 className="hea">For tech finds leaks underground</h1>
        <p className="paragraphs">
          We use the Digital Leak Detector (DLD) to listen for the sound of
          leaks exerting water pressure on the surrounding subsurface material.
        </p>
      </div>

      <div className="card_2">
        <img
          src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/goa-c2-img.png"
          alt="name"
          className="k"
        />
        <h1 className="hea">The Burning Man desert Festival</h1>
        <p className="paragraphs">
          Burning Man is a week-long large-scale desert event focused on
          community, art, self-expression, and western United States
        </p>
      </div>

      <div className="card_3">
        <img
          src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/goa-c3-img.png"
          alt="name"
          className="k"
        />
        <h1 className="hea">Galvanize will build top students</h1>
        <p className="paragraphs">
          He decided to talk loudly and galvanize the team into action. She
          decided to shout at him to galvanize him to take action
        </p>
      </div>
    </div>
  </div>
)

export default Blog
