import {Component} from 'react'

import './index.css'

class Slides extends Component {
  state = {
    activeReviewIndex: 0,
  }

  onClickRightArrow = () => {
    const {activeReviewIndex} = this.state
    const {reviewsList} = this.props

    if (activeReviewIndex < reviewsList.length - 1) {
      this.setState(prevState => ({
        activeReviewIndex: prevState.activeReviewIndex + 1,
      }))
    }
  }

  onClickLeftArrow = () => {
    const {activeReviewIndex} = this.state

    if (activeReviewIndex > 0) {
      this.setState(prevState => ({
        activeReviewIndex: prevState.activeReviewIndex - 1,
      }))
    }
  }

  render() {
    const {reviewsList} = this.props
    const {activeReviewIndex} = this.state
    const currentReviewDetails = reviewsList[activeReviewIndex]
    const {username, description, imgUrl} = currentReviewDetails
    return (
      <div className="home_1">
        <div className="ho_2">
          <h1 className="head">{username}</h1>
          <p className="paragraph">{description}</p>
          <div className="cards-container">
            <h1 className="car_1">
              <img
                src="https://assets.ccbp.in/frontend/react-js/primary-icon-img.png"
                alt="name"
                className="c"
              />
              Professional <br />
              Services
            </h1>
            <h1 className="car_1">
              <img
                src="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
                alt="name"
                className="c"
              />
              Managed IT <br />
              Solution
            </h1>
            <h1 className="car_1">
              <img
                src="https://assets.ccbp.in/frontend/react-js/primary-icon-img.png"
                alt="name"
                className="c"
              />
              Cyber & IT <br />
              Security
            </h1>
          </div>
          <div className="button">
            <button
              type="button"
              onClick={this.onClickLeftArrow}
              className="arrow-button"
            >
              <img
                src="https://assets.ccbp.in/frontend/react-js/left-arrow-img.png"
                alt="left arrow"
              />
            </button>

            <button
              type="button"
              onClick={this.onClickRightArrow}
              className="arrow-button"
            >
              <img
                src="https://assets.ccbp.in/frontend/react-js/right-arrow-img.png"
                alt="right arrow"
              />
            </button>
          </div>
        </div>
        <img src={imgUrl} alt={username} className="img" />
      </div>
    )
  }
}

export default Slides
