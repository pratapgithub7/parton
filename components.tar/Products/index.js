import './index.css'

const Products = () => (
  <div className="project">
    <p className="pro">OUR LATEST PROJECTS</p>
    <h1 className="product_heading">Let`s Know Something</h1>
    <p className="product_p">About Our Work</p>
    <div className="side">
      <img
        src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/goa-c1-img.png"
        className="craze"
        alt="prop"
      />
      <img
        src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/goa-c2-img.png"
        className="craze"
        alt="prop"
      />
      <img
        src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/goa-c3-img.png"
        className="craze"
        alt="prop"
      />
    </div>
  </div>
)

export default Products
