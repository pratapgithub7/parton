import './index.css'

const Feature = () => (
  <div className="f_1">
    <div className="f_2">
      <p className="why">WHY PRINT PARK</p>
      <h1 className="print">Deliver More than you Expect</h1>
      <p className="park">
        There are many variations of passages of lorem but the majority
      </p>
      <div className="hello">
        <div className="row">
          <h1 className="head">Professionalism</h1>
          <p className="paragraph">
            A professional is a member of a profession <br />
            in a specified professional activity.
          </p>
          <h1 className="head">Competitive Prices</h1>
          <p className="paragraph">
            Competitive pricing is the process of <br /> strategically selecting
            price
          </p>
          <h1 className="head">Expertise</h1>
          <p className="paragraph">
            A biologist who knows more about a particular type
            <br /> of fungus than anyone else on the planet
          </p>
        </div>
        <div className="fi">
          <img
            src="https://assets.ccbp.in/frontend/react-js/adrian-williams-img.png"
            className="n"
            alt="name"
          />
        </div>
        <div className="row">
          <h1 className="head">Quality Service</h1>
          <p className="paragraph">
            Service quality is a measure of how an organization <br />
            and fulfills their expectations.
          </p>
          <h1 className="head">Cost Effective</h1>
          <p className="paragraph">
            Something that is cost-effective saves <br /> money in comparison
            with the costs involved.
          </p>
          <h1 className="head">Customization</h1>
          <p className="paragraph">
            the action of making or changing something <br />
            according to the buyer`s or user`s needs:
          </p>
        </div>
      </div>
    </div>
  </div>
)

export default Feature
