import AppStore from '../AppStore'

import Slides from '../Slides'

import About from '../About'

import Products from '../Products'

import Service from '../Service'

import Feature from '../Feature'

import Blog from '../Blog'

import Footer from '../Footer'

import './index.css'

const reviewsList = [
  {
    username: 'Best IT Solution Company Market',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/appointments-app/appointments-img.png',
    description:
      'Technology Services Providers Built for your Unique Needs.We Help position your business for future innovation.',
  },
  {
    username: 'Think Big.We Make IT Solution',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/comments-app/comments-img.png ',
    description:
      'Coming to Startup School is the best thing that has happened to me. I wish every startup in the country should get this opportunity.',
  },
  {
    username: 'You will get 100% Satisfaction',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/appointments-app/appointments-img.png',
    description:
      'I am glad to have such experienced mentors guiding us in every step through out the 4 weeks. I have improved personally and developed many interpersonal skills.',
  },
]

const Home = () => (
  <div>
    <AppStore />
    <div className="home">
      <h1 className="heading">Home</h1>
      <Slides reviewsList={reviewsList} />
    </div>
    <div className="home">
      <h1 className="heading">About</h1>
      <About />
    </div>
    <div className="hom">
      <h1 className="he">Products</h1>
      <Products />
    </div>
    <div className="home">
      <h1 className="heading">Services</h1>
      <Service />
    </div>
    <div className="fea">
      <h1 className="heading">Features</h1>
      <Feature />
    </div>
    <div className="hom">
      <h1 className="he">Blog</h1>
      <Blog />
    </div>
    <div className="hom">
      <h1 className="he">Footer</h1>
      <Footer />
    </div>
  </div>
)

export default Home
